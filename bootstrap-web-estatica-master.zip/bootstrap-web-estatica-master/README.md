# Code
- Página estatica de ejemplo
- Utilizando el framework Bootstrap 4

# Preview
![](img/screenshot.png)
